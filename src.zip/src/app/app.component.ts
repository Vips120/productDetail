import { Component } from '@angular/core';
import {ProductServices} from './Services/product.services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers:[ProductServices],
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
}

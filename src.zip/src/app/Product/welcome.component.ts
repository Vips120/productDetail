import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'welcome.component.html'
})
export class WelcomeComponent implements OnInit {

    private welcome:string;
    private imgUrl:string;
    constructor() { }

    ngOnInit() {

this.welcome ="Welcome";
this.imgUrl ="http://lorempixel.com/400/200/";
     }
}
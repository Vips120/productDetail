import {Component,OnInit} from '@angular/core';

import {Product} from './../shared/product';
import {ProductServices} from './../Services/product.services';
@Component({
     
      selector:'product-list',
      templateUrl:'product.list.component.html',


})

export class ProducListComponent implements OnInit {

private ProductList:string = "Product List";
private products:Product[];
public listfilter:string="";
public productImage:number = 100;
errorMessage:string;

private showImageAction:boolean = false;

constructor(private _productServices:ProductServices){}

ngOnInit()
 {
  this._productServices.getProductData()
   .subscribe((products) => this.products = products,
     error => this.errorMessage = error);
 }

 showToggle()
 {
   this.showImageAction = !this.showImageAction;

 }
 changeView(message:string):void
 {
   this.ProductList = 'Product List :' + message;
 }


}
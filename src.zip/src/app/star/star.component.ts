import {Component,OnChanges,Input,Output,EventEmitter} from '@angular/core';
@Component({
   selector:'star',
   templateUrl:'star.component.html',
   styleUrls:['star.component.css']

})

export class StarComponent implements OnChanges{
 startWidth:number;
@Input() rating:number;
@Output() ratingView:EventEmitter<string> = new EventEmitter<string>();

ngOnChanges()
 {
       this.startWidth = this.rating * 86/5;

 }

onClick()
 {
   this.ratingView.emit(`the new rating was ${this.rating}`);

 }


}
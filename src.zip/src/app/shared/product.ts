export interface Product {
    productId:number;
       product:string;
       code:string;
       available:any;
       price:number;
       rating:any;
       productImage:string

}
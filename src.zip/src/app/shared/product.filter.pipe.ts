import {Pipe,PipeTransform} from '@angular/core';
import {Product} from './../shared/product';


@Pipe({
    name:'ProductFilter'
})

export class FilterProduct implements PipeTransform{

   transform(value:Product[],filterby:string):Product[]
     {
         filterby = filterby ? filterby.toLocaleLowerCase():null;

         return filterby ? value.filter((pro:Product) => pro.product.indexOf(filterby)!==-1):value;
     }

}


import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ProducListComponent } from './Product/product_list.component';
import { FilterProduct } from './shared/product.filter.pipe';
import { StarComponent } from './star/star.component';
import { WelcomeComponent} from './Product/welcome.component';
import { ProductDetailComponent } from './productDetail/product.component';
import {ProductGuardServices } from './guard/product-guard.services';

@NgModule({
  declarations: [
    AppComponent,
    ProducListComponent,
    FilterProduct,
    StarComponent,
    WelcomeComponent,
    ProductDetailComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([{
                              path:'welcome',
                              component:WelcomeComponent
                  },
                  {
                    path:'products',
                    component:ProducListComponent
                  },
                  {
                     path:'product/:productId',
                     component:ProductDetailComponent,
                     canActivate:[ProductGuardServices]
                  },
                  {
                    path:'',
                    redirectTo:'welcome',
                    pathMatch:'full'
                  },{
                    path:'**',
                    redirectTo:'welcome',
                    pathMatch:'full'
                  }
    ])
  ],
  providers: [ProductGuardServices],
  bootstrap: [AppComponent]
})
export class AppModule { }

import {Component,OnInit} from '@angular/core';
import{Router} from '@angular/router';
import {Product} from './../shared/product';
import {ActivatedRoute} from '@angular/router';
import {ProductServices} from './../Services/product.services'
@Component({
      
       templateUrl:'product.detail.component.html'

})

export class ProductDetailComponent implements OnInit {
 id:number;
 Details:string="Product List Detail";
 product:Product;

constructor(private _activatedRoute:ActivatedRoute,
            private _route:Router,
            private _productServices:ProductServices
            ){
    // console.log(this._activatedRoute.snapshot.params['id']);
}

ngOnInit(){
  // let id = +this._activatedRoute.snapshot.params['id'];
  // this.Details +=`: ${id}`;
  
 

    // let id =  +this._activatedRoute.params['id'];
    // this.Details += ` - ${id}`;
    // this._productServices.getProducDetailtData(id)
    //            .subscribe((data) => this.Product=data);

   this._activatedRoute.params
              .subscribe((params) =>{
                let id = params['productId'];
                this.Details += " " + " "+id;
                this._productServices.getProducDetailtData(id).subscribe((data)=> this.product = data)                              
          })
};
onBack()
 {
  this._route.navigate(['/products']);
 }

}